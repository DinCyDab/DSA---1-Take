#include "func.c"

int main(){
    Stack s = init();
    
    push(s, createPerson(createName("Dabon", "Dino Cyrano", 'A'), createBdate(24, 9, 2000)));
    
    printStack(s);
    freeStack(s);
    free(s);
    return 0;
}